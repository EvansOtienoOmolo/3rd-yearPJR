﻿namespace CLASSFingerPrint
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.name_bt = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.time_bt = new System.Windows.Forms.Label();
            this.unit_bt = new System.Windows.Forms.Label();
            this.Attend_bt = new System.Windows.Forms.Button();
            this.cancel_bt = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Reg_bt = new System.Windows.Forms.Label();
            this.unit_f = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.name_f = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.id_bt = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.id_bt);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.name_bt);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.time_bt);
            this.panel1.Controls.Add(this.unit_bt);
            this.panel1.Controls.Add(this.Attend_bt);
            this.panel1.Controls.Add(this.cancel_bt);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.Reg_bt);
            this.panel1.Controls.Add(this.unit_f);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.name_f);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(760, 531);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(482, 479);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(113, 33);
            this.button4.TabIndex = 14;
            this.button4.Text = "COMPARE";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(616, 444);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 33);
            this.button3.TabIndex = 13;
            this.button3.Text = "PIC FILE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(366, 444);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 33);
            this.button2.TabIndex = 12;
            this.button2.Text = "PICK FILE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox2.Location = new System.Drawing.Point(585, 279);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 140);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // name_bt
            // 
            this.name_bt.AutoSize = true;
            this.name_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_bt.Location = new System.Drawing.Point(29, 38);
            this.name_bt.Name = "name_bt";
            this.name_bt.Size = new System.Drawing.Size(59, 20);
            this.name_bt.TabIndex = 10;
            this.name_bt.Text = "NAME";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Location = new System.Drawing.Point(366, 279);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // time_bt
            // 
            this.time_bt.AutoSize = true;
            this.time_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time_bt.Location = new System.Drawing.Point(29, 107);
            this.time_bt.Name = "time_bt";
            this.time_bt.Size = new System.Drawing.Size(51, 20);
            this.time_bt.TabIndex = 9;
            this.time_bt.Text = "TIME";
            this.time_bt.Click += new System.EventHandler(this.label3_Click);
            // 
            // unit_bt
            // 
            this.unit_bt.AutoSize = true;
            this.unit_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unit_bt.Location = new System.Drawing.Point(336, 106);
            this.unit_bt.Name = "unit_bt";
            this.unit_bt.Size = new System.Drawing.Size(50, 20);
            this.unit_bt.TabIndex = 8;
            this.unit_bt.Text = "UNIT";
            // 
            // Attend_bt
            // 
            this.Attend_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Attend_bt.Location = new System.Drawing.Point(158, 194);
            this.Attend_bt.Name = "Attend_bt";
            this.Attend_bt.Size = new System.Drawing.Size(91, 33);
            this.Attend_bt.TabIndex = 7;
            this.Attend_bt.Text = "ATTEND";
            this.Attend_bt.UseVisualStyleBackColor = true;
            this.Attend_bt.Click += new System.EventHandler(this.Attend_bt_Click);
            // 
            // cancel_bt
            // 
            this.cancel_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_bt.Location = new System.Drawing.Point(436, 204);
            this.cancel_bt.Name = "cancel_bt";
            this.cancel_bt.Size = new System.Drawing.Size(90, 33);
            this.cancel_bt.TabIndex = 6;
            this.cancel_bt.Text = "CANCEL";
            this.cancel_bt.UseVisualStyleBackColor = true;
            this.cancel_bt.Click += new System.EventHandler(this.cancel_bt_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "7:00AM-9:00AM",
            "9:00AM-11:00AM",
            "11:00AM-1:00PM",
            "1:00PM-3:00PM",
            "3:00PM-5:00PM",
            "5:00PM-7:00PM"});
            this.comboBox1.Location = new System.Drawing.Point(158, 99);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 5;
            // 
            // Reg_bt
            // 
            this.Reg_bt.AutoSize = true;
            this.Reg_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reg_bt.Location = new System.Drawing.Point(336, 38);
            this.Reg_bt.Name = "Reg_bt";
            this.Reg_bt.Size = new System.Drawing.Size(83, 20);
            this.Reg_bt.TabIndex = 4;
            this.Reg_bt.Text = "REG NO.";
            this.Reg_bt.Click += new System.EventHandler(this.Reg_f_Click);
            // 
            // unit_f
            // 
            this.unit_f.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.unit_f.Location = new System.Drawing.Point(436, 99);
            this.unit_f.Name = "unit_f";
            this.unit_f.Size = new System.Drawing.Size(169, 26);
            this.unit_f.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBox2.Location = new System.Drawing.Point(436, 35);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(169, 26);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // name_f
            // 
            this.name_f.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.name_f.Location = new System.Drawing.Point(107, 38);
            this.name_f.Name = "name_f";
            this.name_f.Size = new System.Drawing.Size(172, 26);
            this.name_f.TabIndex = 0;
            this.name_f.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(37, 459);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 44);
            this.button1.TabIndex = 11;
            this.button1.Text = "REGISTER";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // id_bt
            // 
            this.id_bt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.id_bt.Location = new System.Drawing.Point(107, 146);
            this.id_bt.Name = "id_bt";
            this.id_bt.Size = new System.Drawing.Size(172, 26);
            this.id_bt.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 547);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "KISII UNIVERSITY ATTENDANCE COLLECTION";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox name_f;
        private System.Windows.Forms.Label name_bt;
        private System.Windows.Forms.Label time_bt;
        private System.Windows.Forms.Label unit_bt;
        private System.Windows.Forms.Button Attend_bt;
        private System.Windows.Forms.Button cancel_bt;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label Reg_bt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox unit_f;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox id_bt;
        private System.Windows.Forms.Label label1;
    }
}

